﻿namespace MusicHub.Data
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Config
    {
        public const string ConnectionString = @"Server=DESKTOP-5MFDNNE\SQLEXPRESS;Database=MusicHub;Integrated Security = True;";
    }
}
