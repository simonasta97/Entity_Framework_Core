﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Theatre;Trusted_Connection=True";
    }
}
