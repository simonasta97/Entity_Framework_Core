﻿namespace ProductShop.Dtos.Input
{
    using System;
    using System.Collections.Generic;
    using System.Text;


    public class UserInputDto
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public int? Age { get; set; }
    }
}
