﻿namespace P03_FootballBetting.Data
{
    public static class Config
    {
        public const string ConnectionString = @"Server=DESKTOP-5MFDNNE\SQLEXPRESS;Database=Bet;Integrated Security = True;";
    }
}
